// ====== GOOGLE GEMINI API + HINDI VOICE ASSISTANT ======
const API_KEY = "AIzaSyC_SKjprc-yy1VJSRgC2RNUBAigZPQAtQg";
const r = new (webkitSpeechRecognition || SpeechRecognition)();
r.lang = 'hi-IN';

let output = document.getElementById("out");
let isMuted = false;
let isListening = false;
let availableVoices = [];

// ====== Load Voices ======
function loadVoices() {
  availableVoices = speechSynthesis.getVoices();
  if (availableVoices.length === 0) {
    // Chrome loads voices asynchronously
    speechSynthesis.onvoiceschanged = () => {
      availableVoices = speechSynthesis.getVoices();
    };
  }
}
loadVoices();

// ====== Start Button Function ======
function handleclick() {
  if (isListening) return;
  output.innerText = "🎧 सुन रहा हूँ...";
  r.start();
  isListening = true;
}

// ====== Voice Recognition Result ======
r.onresult = async (e) => {
  if (isMuted) return; // Skip if muted
  const t = e.results[0][0].transcript;
  output.innerText = `🗣️ आपने कहा: "${t}"\n\nसोच रहा हूँ...`;

  try {
    // ====== Send Query to Gemini ======
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: t }] }]
        })
      }
    );

    const data = await res.json();
    const reply = data.candidates?.[0]?.content?.parts?.[0]?.text || "मुझे समझ नहीं आया।";

    // ====== Speak & Show Reply ======
    speakReply(reply);
    output.innerHTML = `💬 उत्तर: ${reply}`;
  } catch (err) {
    console.error(err);
    output.innerText = "⚠️ कुछ त्रुटि हुई।";
  }
};

// ====== Speak Reply Function ======
function speakReply(text) {
  const u = new SpeechSynthesisUtterance(text);
  u.lang = 'hi-IN';

  let hiVoice = availableVoices.find(v => v.lang === 'hi-IN' || v.name.toLowerCase().includes("hindi"));
  if (!hiVoice) {
    hiVoice = availableVoices.find(v => v.lang === 'en-IN') || availableVoices[0];
  }
  if (hiVoice) u.voice = hiVoice;

  setTimeout(() => {
    speechSynthesis.cancel();
    speechSynthesis.speak(u);
  }, 500);
}

// ====== Connect Mute Button ======
function toggleMute() {
  const muteBtn = document.getElementById("muteBtn");
  isMuted = !isMuted;

  if (isMuted) {
    muteBtn.textContent = "🔈 अनम्यूट";
    muteBtn.style.boxShadow = "0 0 15px red";
    muteBtn.style.color = "#ff4d4d";
    speechSynthesis.cancel(); // Stop any current speaking
  } else {
    muteBtn.textContent = "🔇 म्यूट";
    muteBtn.style.boxShadow = "none";
    muteBtn.style.color = "#00ffe1";
  }

  output.innerText = isMuted
    ? "🔇 असिस्टेंट म्यूट है।"
    : "🔈 असिस्टेंट सक्रिय है।";
}

// ====== Connect End Call Button ======
function endCall() {
  if (r && isListening) {
    r.stop();
    isListening = false;
  }

  speechSynthesis.cancel(); // Stop all voices
  output.innerText = "📞 कॉल समाप्त। धन्यवाद!";
}
