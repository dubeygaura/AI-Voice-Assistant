from django.shortcuts import render

# Create your views here.
def Ai_Agent(request):
    return render(request, 'Ai_Agent.html')